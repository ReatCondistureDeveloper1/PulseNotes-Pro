package com.reatcondisture.pulsenotespro;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import com.reatcondisture.pulsenotespro.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private MainBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		// 1. VERİ YAPISI VE DOKUNSAL GERİ BİLDİRİM
		final android.content.SharedPreferences prefs = getSharedPreferences("PulseNotesProData", MODE_PRIVATE);
		final java.util.ArrayList<org.json.JSONObject> masterNoteList = new java.util.ArrayList<>();
		final String[] selectedCategory = {"Tümü"};
		
		final android.os.Vibrator vibrator = (android.os.Vibrator) getSystemService(android.content.Context.VIBRATOR_SERVICE);
		final Runnable triggerVibration = new Runnable() {
			@Override
			public void run() {
				try {
					if (vibrator != null && vibrator.hasVibrator()) {
						if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
							vibrator.vibrate(android.os.VibrationEffect.createOneShot(15, android.os.VibrationEffect.DEFAULT_AMPLITUDE));
						} else {
							vibrator.vibrate(15);
						}
					}
				} catch (Exception ignored) {}
			}
		};
		
		// Kayıtlı JSON Verilerini Yükle
		String rawJsonData = prefs.getString("notes_json", "[]");
		try {
			org.json.JSONArray jsonArray = new org.json.JSONArray(rawJsonData);
			for (int i = 0; i < jsonArray.length(); i++) {
				masterNoteList.add(jsonArray.getJSONObject(i));
			}
		} catch (Exception e) { e.printStackTrace(); }
		
		// 2. ROOT LAYOUT (GRADIENT ARKA PLAN)
		android.graphics.drawable.GradientDrawable bgGradient = new android.graphics.drawable.GradientDrawable(
		android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
		new int[] { 0xFF0F172A, 0xFF1E1B4B, 0xFF090D16 }
		);
		
		android.widget.LinearLayout rootLayout = new android.widget.LinearLayout(this);
		rootLayout.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-1, -1));
		rootLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
		rootLayout.setPadding(40, 50, 40, 20);
		rootLayout.setBackground(bgGradient);
		
		// 3. APPLE STYLE ÜST BAŞLIK & İSTATİSTİK
		android.widget.LinearLayout headerLayout = new android.widget.LinearLayout(this);
		headerLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		headerLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
		headerLayout.setPadding(0, 10, 0, 25);
		
		android.widget.TextView txtTitle = new android.widget.TextView(this);
		txtTitle.setText("Notlar");
		txtTitle.setTextSize(32);
		txtTitle.setTextColor(0xFFFFFFFF);
		txtTitle.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD));
		txtTitle.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, -2, 1.0f));
		
		final android.widget.TextView txtBadge = new android.widget.TextView(this);
		txtBadge.setTextSize(12);
		txtBadge.setTextColor(0xFF38BDF8);
		txtBadge.setPadding(25, 10, 25, 10);
		android.graphics.drawable.GradientDrawable badgeBg = new android.graphics.drawable.GradientDrawable();
		badgeBg.setCornerRadius(30f);
		badgeBg.setColor(0x2238BDF8);
		txtBadge.setBackground(badgeBg);
		
		headerLayout.addView(txtTitle);
		headerLayout.addView(txtBadge);
		rootLayout.addView(headerLayout);
		
		// 4. NEON KATEGORİ SEÇİCİ
		android.widget.HorizontalScrollView categoryScroll = new android.widget.HorizontalScrollView(this);
		categoryScroll.setHorizontalScrollBarEnabled(false);
		categoryScroll.setPadding(0, 0, 0, 25);
		
		final android.widget.LinearLayout categoryContainer = new android.widget.LinearLayout(this);
		categoryContainer.setOrientation(android.widget.LinearLayout.HORIZONTAL);
		
		final String[] categories = {"Tümü", "Kişisel", "İş", "Fikirler", "Acil"};
		final int[] categoryColors = {0xFF38BDF8, 0xFF3B82F6, 0xFFA855F7, 0xFFEAB308, 0xFFEF4444};
		final java.util.ArrayList<android.widget.TextView> categoryViews = new java.util.ArrayList<>();
		
		// 5. YENİ NOT EKLEME BUTONU
		final android.widget.Button btnOpenDialog = new android.widget.Button(this);
		btnOpenDialog.setText("+ Yeni Not Yaz");
		btnOpenDialog.setTextSize(15);
		btnOpenDialog.setTextColor(0xFFFFFFFF);
		btnOpenDialog.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
		btnOpenDialog.setPadding(0, 30, 0, 30);
		
		android.graphics.drawable.GradientDrawable btnOpenBg = new android.graphics.drawable.GradientDrawable();
		btnOpenBg.setCornerRadius(25f);
		btnOpenBg.setColor(0xFF10B981); // Neon Emerald
		btnOpenDialog.setBackground(btnOpenBg);
		
		android.widget.LinearLayout.LayoutParams openBtnParams = new android.widget.LinearLayout.LayoutParams(-1, -2);
		openBtnParams.setMargins(0, 0, 0, 25);
		btnOpenDialog.setLayoutParams(openBtnParams);
		
		rootLayout.addView(categoryScroll);
		categoryScroll.addView(categoryContainer);
		rootLayout.addView(btnOpenDialog);
		
		// 6. SCROLLVIEW & CONTAINER
		android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
		scrollView.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-1, 0, 1.0f));
		
		final android.widget.LinearLayout listContainer = new android.widget.LinearLayout(this);
		listContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
		scrollView.addView(listContainer);
		
		// 7. FOOTER
		android.widget.TextView txtFooter = new android.widget.TextView(this);
		txtFooter.setText("Developed by Reat Condisture © 2026");
		txtFooter.setTextSize(11);
		txtFooter.setTextColor(0x6694A3B8);
		txtFooter.setGravity(android.view.Gravity.CENTER);
		txtFooter.setPadding(0, 15, 0, 0);
		
		rootLayout.addView(scrollView);
		rootLayout.addView(txtFooter);
		
		setContentView(rootLayout);
		
		// 8. VERİ KAYDETME VE DIALOG MANTIKLARI
		final Runnable saveToPrefs = new Runnable() {
			@Override
			public void run() {
				org.json.JSONArray array = new org.json.JSONArray();
				for (org.json.JSONObject obj : masterNoteList) array.put(obj);
				prefs.edit().putString("notes_json", array.toString()).apply();
			}
		};
		
		final Runnable[] renderListHolder = new Runnable[1];
		
		// DRAFT (TASLAK) YÖNETİM METOTLARI
		final Runnable clearDraft = new Runnable() {
			@Override
			public void run() {
				prefs.edit().remove("draft_title").remove("draft_content").remove("draft_category").apply();
			}
		};
		
		final java.util.concurrent.atomic.AtomicReference<Runnable> openEditorDialog = new java.util.concurrent.atomic.AtomicReference<>();
		
		openEditorDialog.set(new Runnable() {
			public org.json.JSONObject targetNote = null;
			public int editIndex = -1;
			
			@Override
			public void run() {
				triggerVibration.run();
				
				final android.app.Dialog noteDialog = new android.app.Dialog(MainActivity.this, android.R.style.Theme_Translucent_NoTitleBar_Fullscreen);
				
				final android.widget.LinearLayout modalRoot = new android.widget.LinearLayout(MainActivity.this);
				modalRoot.setOrientation(android.widget.LinearLayout.VERTICAL);
				modalRoot.setPadding(50, 60, 50, 50);
				
				android.graphics.drawable.GradientDrawable modalBg = new android.graphics.drawable.GradientDrawable(
				android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
				new int[] { 0xFF0F172A, 0xFF1E1B4B }
				);
				modalRoot.setBackground(modalBg);
				
				// Apple Style Top Bar
				android.widget.LinearLayout topBar = new android.widget.LinearLayout(MainActivity.this);
				topBar.setOrientation(android.widget.LinearLayout.HORIZONTAL);
				topBar.setGravity(android.view.Gravity.CENTER_VERTICAL);
				
				android.widget.TextView btnClose = new android.widget.TextView(MainActivity.this);
				btnClose.setText("Vazgeç");
				btnClose.setTextColor(0xFFEF4444);
				btnClose.setTextSize(16);
				btnClose.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
				btnClose.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, -2, 1.0f));
				
				android.widget.Button btnSaveNote = new android.widget.Button(MainActivity.this);
				btnSaveNote.setText(targetNote == null ? "Ekle" : "Bitti");
				btnSaveNote.setTextSize(14);
				btnSaveNote.setTextColor(0xFFFFFFFF);
				btnSaveNote.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
				
				android.graphics.drawable.GradientDrawable saveBg = new android.graphics.drawable.GradientDrawable();
				saveBg.setCornerRadius(20f);
				saveBg.setColor(0xFF38BDF8);
				btnSaveNote.setBackground(saveBg);
				
				topBar.addView(btnClose);
				topBar.addView(btnSaveNote);
				
				// Kategori Seçici
				String defaultCat = "Kişisel";
				if (targetNote != null) {
					defaultCat = targetNote.optString("category", "Kişisel");
				} else if (prefs.contains("draft_category")) {
					defaultCat = prefs.getString("draft_category", "Kişisel");
				}
				
				final String[] modalSelectedCat = { defaultCat };
				android.widget.HorizontalScrollView modalCatScroll = new android.widget.HorizontalScrollView(MainActivity.this);
				modalCatScroll.setHorizontalScrollBarEnabled(false);
				modalCatScroll.setPadding(0, 30, 0, 20);
				
				android.widget.LinearLayout modalCatContainer = new android.widget.LinearLayout(MainActivity.this);
				modalCatContainer.setOrientation(android.widget.LinearLayout.HORIZONTAL);
				
				final String[] writableCats = {"Kişisel", "İş", "Fikirler", "Acil"};
				final java.util.ArrayList<android.widget.TextView> modalCatViews = new java.util.ArrayList<>();
				
				for (int m = 0; m < writableCats.length; m++) {
					final String mCatName = writableCats[m];
					
					final android.widget.TextView mCatTv = new android.widget.TextView(MainActivity.this);
					mCatTv.setText(mCatName);
					mCatTv.setTextSize(12);
					mCatTv.setPadding(30, 12, 30, 12);
					mCatTv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
					
					android.widget.LinearLayout.LayoutParams mp = new android.widget.LinearLayout.LayoutParams(-2, -2);
					mp.setMargins(0, 0, 12, 0);
					mCatTv.setLayoutParams(mp);
					
					modalCatViews.add(mCatTv);
					
					mCatTv.setOnClickListener(new android.view.View.OnClickListener() {
						@Override
						public void onClick(android.view.View view) {
							triggerVibration.run();
							modalSelectedCat[0] = mCatName;
							if (targetNote == null) prefs.edit().putString("draft_category", mCatName).apply();
							
							for (int k = 0; k < modalCatViews.size(); k++) {
								boolean isSel = writableCats[k].equals(modalSelectedCat[0]);
								android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
								shape.setCornerRadius(25f);
								shape.setColor(isSel ? (categoryColors[k + 1] & 0x44FFFFFF) : 0x1AFFFFFF);
								shape.setStroke(2, isSel ? categoryColors[k + 1] : 0x22FFFFFF);
								modalCatViews.get(k).setBackground(shape);
								modalCatViews.get(k).setTextColor(isSel ? categoryColors[k + 1] : 0x88FFFFFF);
							}
						}
					});
					
					modalCatContainer.addView(mCatTv);
				}
				modalCatScroll.addView(modalCatContainer);
				
				// NOT BAŞLIĞI ALANI
				final android.widget.EditText edtTitle = new android.widget.EditText(MainActivity.this);
				edtTitle.setHint("Başlık");
				edtTitle.setHintTextColor(0x44FFFFFF);
				edtTitle.setTextColor(0xFF38BDF8);
				edtTitle.setTextSize(22);
				edtTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
				edtTitle.setPadding(20, 20, 20, 10);
				edtTitle.setBackground(null);
				
				// NOT İÇERİK ALANI
				final android.widget.EditText edtContent = new android.widget.EditText(MainActivity.this);
				edtContent.setHint("Notunuzu buraya yazın...");
				edtContent.setHintTextColor(0x44FFFFFF);
				edtContent.setTextColor(0xFFFFFFFF);
				edtContent.setTextSize(16);
				edtContent.setGravity(android.view.Gravity.TOP);
				edtContent.setPadding(20, 10, 20, 20);
				edtContent.setBackground(null);
				
				// VERİ VEYA TASLAK YÜKLEME (RESTORE DRAFT)
				if (targetNote != null) {
					edtTitle.setText(targetNote.optString("title", ""));
					edtContent.setText(targetNote.optString("content", ""));
				} else {
					edtTitle.setText(prefs.getString("draft_title", ""));
					edtContent.setText(prefs.getString("draft_content", ""));
				}
				
				// ANLIK OTOMATİK TASLAK KAYDI (AUTO-DRAFT TEXT LISTENER)
				android.text.TextWatcher draftWatcher = new android.text.TextWatcher() {
					@Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
					@Override public void onTextChanged(CharSequence s, int start, int before, int count) {
						if (targetNote == null) {
							prefs.edit()
							.putString("draft_title", edtTitle.getText().toString())
							.putString("draft_content", edtContent.getText().toString())
							.apply();
						}
					}
					@Override public void afterTextChanged(android.text.Editable s) {}
				};
				edtTitle.addTextChangedListener(draftWatcher);
				edtContent.addTextChangedListener(draftWatcher);
				
				android.widget.LinearLayout.LayoutParams areaParams = new android.widget.LinearLayout.LayoutParams(-1, 0, 1.0f);
				edtContent.setLayoutParams(areaParams);
				
				modalRoot.addView(topBar);
				modalRoot.addView(modalCatScroll);
				modalRoot.addView(edtTitle);
				modalRoot.addView(edtContent);
				
				noteDialog.setContentView(modalRoot);
				
				// SLIDE UP ANİMASYONU
				modalRoot.setTranslationY(1200f);
				noteDialog.show();
				modalRoot.animate()
				.translationY(0f)
				.setDuration(350)
				.setInterpolator(new android.view.animation.OvershootInterpolator(0.8f))
				.start();
				
				// Kategori Seçimi
				for (int k = 0; k < writableCats.length; k++) {
					if (writableCats[k].equals(modalSelectedCat[0])) {
						modalCatViews.get(k).performClick();
						break;
					}
				}
				
				// Kapat / Vazgeç Butonu
				btnClose.setOnClickListener(new android.view.View.OnClickListener() {
					@Override
					public void onClick(android.view.View view) {
						modalRoot.animate()
						.translationY(1200f)
						.setDuration(250)
						.withEndAction(new Runnable() {
							@Override
							public void run() {
								noteDialog.dismiss();
							}
						}).start();
					}
				});
				
				// Kaydet / Düzenle Butonu
				btnSaveNote.setOnClickListener(new android.view.View.OnClickListener() {
					@Override
					public void onClick(android.view.View view) {
						String title = edtTitle.getText().toString().trim();
						String content = edtContent.getText().toString().trim();
						
						if (title.isEmpty() && content.isEmpty()) return;
						
						if (title.isEmpty()) {
							title = content.contains("\n") ? content.substring(0, content.indexOf("\n")) : content;
							if (title.length() > 25) title = title.substring(0, 25) + "...";
						}
						
						triggerVibration.run();
						try {
							org.json.JSONObject noteObj = (targetNote != null) ? targetNote : new org.json.JSONObject();
							if (targetNote == null) noteObj.put("id", System.currentTimeMillis());
							
							noteObj.put("title", title);
							noteObj.put("content", content);
							noteObj.put("category", modalSelectedCat[0]);
							
							java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale.getDefault());
							noteObj.put("date", sdf.format(new java.util.Date()));
							
							if (targetNote == null) {
								masterNoteList.add(0, noteObj);
								clearDraft.run(); // Not eklendiğinde taslağı temizle
							} else if (editIndex != -1) {
								masterNoteList.set(editIndex, noteObj);
							}
							
							saveToPrefs.run();
							renderListHolder[0].run();
							
							modalRoot.animate()
							.translationY(1200f)
							.setDuration(250)
							.withEndAction(new Runnable() {
								@Override
								public void run() {
									noteDialog.dismiss();
								}
							}).start();
							
						} catch (Exception e) { e.printStackTrace(); }
					}
				});
			}
		});
		
		// LISTE OLUŞTURMA MANTIKLARI
		renderListHolder[0] = new Runnable() {
			@Override
			public void run() {
				listContainer.removeAllViews();
				int visibleCount = 0;
				
				for (int i = 0; i < masterNoteList.size(); i++) {
					final int index = i;
					try {
						final org.json.JSONObject note = masterNoteList.get(i);
						String cat = note.optString("category", "Tümü");
						
						if (!selectedCategory[0].equals("Tümü") && !cat.equals(selectedCategory[0])) {
							continue;
						}
						visibleCount++;
						
						int colorAccent = 0xFF38BDF8;
						for (int c = 0; c < categories.length; c++) {
							if (categories[c].equals(cat)) { colorAccent = categoryColors[c]; break; }
						}
						
						// Apple Style Not Kartı
						final android.widget.LinearLayout card = new android.widget.LinearLayout(MainActivity.this);
						card.setOrientation(android.widget.LinearLayout.VERTICAL);
						card.setPadding(35, 30, 35, 30);
						
						android.graphics.drawable.GradientDrawable cardBg = new android.graphics.drawable.GradientDrawable();
						cardBg.setCornerRadius(24f);
						cardBg.setColor(0x1AFFFFFF);
						cardBg.setStroke(2, colorAccent & 0x55FFFFFF);
						card.setBackground(cardBg);
						
						android.widget.LinearLayout.LayoutParams cardParams = new android.widget.LinearLayout.LayoutParams(-1, -2);
						cardParams.setMargins(0, 0, 0, 20);
						card.setLayoutParams(cardParams);
						
						// Kart Üst Bar
						android.widget.LinearLayout cardHeader = new android.widget.LinearLayout(MainActivity.this);
						cardHeader.setOrientation(android.widget.LinearLayout.HORIZONTAL);
						
						android.widget.TextView tvCat = new android.widget.TextView(MainActivity.this);
						tvCat.setText(cat.toUpperCase());
						tvCat.setTextSize(10);
						tvCat.setTextColor(colorAccent);
						tvCat.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
						tvCat.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, -2, 1.0f));
						
						android.widget.TextView btnDelete = new android.widget.TextView(MainActivity.this);
						btnDelete.setText("✕");
						btnDelete.setTextColor(0x88EF4444);
						btnDelete.setTextSize(15);
						btnDelete.setPadding(10, 0, 10, 0);
						
						cardHeader.addView(tvCat);
						cardHeader.addView(btnDelete);
						
						// Not Başlığı
						android.widget.TextView tvNoteTitle = new android.widget.TextView(MainActivity.this);
						tvNoteTitle.setText(note.optString("title", "İsimsiz Not"));
						tvNoteTitle.setTextColor(0xFFFFFFFF);
						tvNoteTitle.setTextSize(17);
						tvNoteTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
						tvNoteTitle.setPadding(0, 8, 0, 4);
						
						// Not Detay İçeriği
						android.widget.TextView tvContent = new android.widget.TextView(MainActivity.this);
						tvContent.setText(note.optString("content", ""));
						tvContent.setTextColor(0xCCF8FAFC);
						tvContent.setTextSize(14);
						tvContent.setMaxLines(2);
						tvContent.setEllipsize(android.text.TextUtils.TruncateAt.END);
						
						// Tarih
						android.widget.TextView tvDate = new android.widget.TextView(MainActivity.this);
						tvDate.setText(note.optString("date", ""));
						tvDate.setTextColor(0x55FFFFFF);
						tvDate.setTextSize(10);
						tvDate.setPadding(0, 8, 0, 0);
						
						card.addView(cardHeader);
						card.addView(tvNoteTitle);
						card.addView(tvContent);
						card.addView(tvDate);
						
						// TOUCH DOWN / TOUCH UP
						card.setOnTouchListener(new android.view.View.OnTouchListener() {
							@Override
							public boolean onTouch(android.view.View v, android.view.MotionEvent event) {
								if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) {
									v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(100).start();
								} else if (event.getAction() == android.view.MotionEvent.ACTION_UP || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) {
									v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(150).start();
								}
								return false;
							}
						});
						
						// KARTA TIKLANDIĞINDA DÜZENLE
						card.setOnClickListener(new android.view.View.OnClickListener() {
							@Override
							public void onClick(android.view.View v) {
								try {
									Runnable r = openEditorDialog.get();
									r.getClass().getField("targetNote").set(r, note);
									r.getClass().getField("editIndex").set(r, index);
									r.run();
								} catch (Exception e) { e.printStackTrace(); }
							}
						});
						
						// Silme Animasyonu
						btnDelete.setOnClickListener(new android.view.View.OnClickListener() {
							@Override
							public void onClick(android.view.View v) {
								triggerVibration.run();
								card.animate()
								.translationX(v.getWidth() * 2f)
								.alpha(0f)
								.setDuration(250)
								.setInterpolator(new android.view.animation.AccelerateInterpolator())
								.withEndAction(new Runnable() {
									@Override
									public void run() {
										masterNoteList.remove(index);
										saveToPrefs.run();
										renderListHolder[0].run();
									}
								}).start();
							}
						});
						
						listContainer.addView(card);
						
						// STAGGERED ENTRANCE ANİMASYONU
						card.setTranslationY(100f);
						card.setAlpha(0f);
						card.animate()
						.translationY(0f)
						.alpha(1f)
						.setDuration(300)
						.setStartDelay(visibleCount * 30L)
						.setInterpolator(new android.view.animation.DecelerateInterpolator())
						.start();
						
					} catch (Exception e) { e.printStackTrace(); }
				}
				
				txtBadge.setText(visibleCount + " Not");
			}
		};
		
		final Runnable renderList = renderListHolder[0];
		
		// Kategori Butonları
		for (int i = 0; i < categories.length; i++) {
			final String catName = categories[i];
			
			final android.widget.TextView catTv = new android.widget.TextView(this);
			catTv.setText(catName);
			catTv.setTextSize(13);
			catTv.setPadding(35, 15, 35, 15);
			catTv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
			
			android.widget.LinearLayout.LayoutParams p = new android.widget.LinearLayout.LayoutParams(-2, -2);
			p.setMargins(0, 0, 15, 0);
			catTv.setLayoutParams(p);
			
			categoryViews.add(catTv);
			
			catTv.setOnClickListener(new android.view.View.OnClickListener() {
				@Override
				public void onClick(android.view.View v) {
					triggerVibration.run();
					selectedCategory[0] = catName;
					
					for (int k = 0; k < categoryViews.size(); k++) {
						boolean isSelected = categories[k].equals(selectedCategory[0]);
						android.graphics.drawable.GradientDrawable shape = new android.graphics.drawable.GradientDrawable();
						shape.setCornerRadius(30f);
						shape.setColor(isSelected ? (categoryColors[k] & 0x44FFFFFF) : 0x1AFFFFFF);
						shape.setStroke(2, isSelected ? categoryColors[k] : 0x22FFFFFF);
						categoryViews.get(k).setBackground(shape);
						categoryViews.get(k).setTextColor(isSelected ? categoryColors[k] : 0x88FFFFFF);
					}
					renderList.run();
				}
			});
			
			categoryContainer.addView(catTv);
		}
		
		categoryViews.get(0).performClick();
		
		// YENİ NOT EKLE
		btnOpenDialog.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(android.view.View v) {
				try {
					Runnable r = openEditorDialog.get();
					r.getClass().getField("targetNote").set(r, null);
					r.getClass().getField("editIndex").set(r, -1);
					r.run();
				} catch (Exception e) { e.printStackTrace(); }
			}
		});
		
	}
	
}